# made on 09/25/2017
1. Compile **.f95 first by the command inside. We can modify the model and parameter priors inside.
2. Run mcmc_fit_p0_BAO.py by the command written in the reader.
